# Changelog


### 0.8.3

- throw ManuallyLockedException with ETA.


### 0.8.2

- compat NC19


### 0.8.1

Beta release, nc18
