OC.L10N.register(
    "files_lock",
    {
    "Unlock file" : "Odomknúť súbor",
    "Lock file" : "Zamknúť súbor",
    "Locked by {0}" : "Zamkol/Zamkla {0}",
    "Temporary files lock" : "Dočasný zámok súborov",
    "Temporary lock your files" : "Dočasne zamykajte svoje súbory",
    "Allow your users to temporary lock their files to avoid conflicts while working on shared files." : "Umožňuje vašim používateľom dočasne zamykať svoje súbory a vyhýbať sa tak konfliktom pri práci na zdieľaných súboroch."
},
"nplurals=4; plural=(n % 1 == 0 && n == 1 ? 0 : n % 1 == 0 && n >= 2 && n <= 4 ? 1 : n % 1 != 0 ? 2: 3);");
