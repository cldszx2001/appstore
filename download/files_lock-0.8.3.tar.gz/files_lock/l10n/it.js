OC.L10N.register(
    "files_lock",
    {
    "Unlock file" : "Sblocca file",
    "Lock file" : "Blocca file",
    "Locked by {0}" : "Bloccato da {0}",
    "Temporary files lock" : "Blocco temporaneo dei file",
    "Temporary lock your files" : "Blocca temporaneamente i tuoi file",
    "Allow your users to temporary lock their files to avoid conflicts while working on shared files." : "Consenti ai tuoi utenti di bloccare temporaneamente i loro file per evitare conflitti mentre lavorano su file condivisi."
},
"nplurals=2; plural=(n != 1);");
