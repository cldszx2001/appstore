OC.L10N.register(
    "files_lock",
    {
    "Unlock file" : "Datei entsperren",
    "Lock file" : "Datei sperren",
    "Locked by {0}" : "Gesperrt von {0}",
    "Temporary files lock" : "Dateien temporär sperren",
    "Temporary lock your files" : "Deine Dateien temporär sperren",
    "Allow your users to temporary lock their files to avoid conflicts while working on shared files." : "Erlaubt es Benutzern eine Datei temporär zu sperren um Konflikte während der Arbeit an geteilten Dateien zu vermeiden."
},
"nplurals=2; plural=(n != 1);");
