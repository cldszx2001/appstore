OC.L10N.register(
    "files_lock",
    {
    "Unlock file" : "Dosya kilidini aç",
    "Lock file" : "Dosyayı kilitle",
    "Locked by {0}" : "{0} tarafından kilitlenmiş",
    "Temporary files lock" : "Geçici dosya kilidi",
    "Temporary lock your files" : "Dosyalarınızı geçici olarak kilitleyin",
    "Allow your users to temporary lock their files to avoid conflicts while working on shared files." : "Kullanıcılar paylaşımlı dosyalar üzerinde çalışırken, çakışmaların engellenmesi için dosyaların geçici olarak kilitlenmesini sağlar."
},
"nplurals=2; plural=(n > 1);");
