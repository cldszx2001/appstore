OC.L10N.register(
    "files_lock",
    {
    "Unlock file" : "Otključaj datoteku",
    "Lock file" : "Zaključaj datoteku",
    "Locked by {0}" : "Zaključao {0}",
    "Temporary files lock" : "Privremeno zaključavanje datoteka",
    "Temporary lock your files" : "Privremeno zaključajte datoteke",
    "Allow your users to temporary lock their files to avoid conflicts while working on shared files." : "Omogućite korisnicima da privremeno zaključaju datoteke kako bi izbjegli nepodudaranja tijekom rada s dijeljenim datotekama."
},
"nplurals=3; plural=n%10==1 && n%100!=11 ? 0 : n%10>=2 && n%10<=4 && (n%100<10 || n%100>=20) ? 1 : 2;");
