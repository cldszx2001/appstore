OC.L10N.register(
    "files_lock",
    {
    "Unlock file" : "Odblokuj plik",
    "Lock file" : "Zablokuj plik",
    "Locked by {0}" : "Zablokowany przez {0}",
    "Temporary files lock" : "Tymczasowa blokada plików",
    "Temporary lock your files" : "Tymczasowo zablokuj swoje pliki",
    "Allow your users to temporary lock their files to avoid conflicts while working on shared files." : "Zezwól użytkownikom na tymczasowe blokowanie swoich plików, aby uniknąć konfliktów podczas pracy na udostępnionych plikach."
},
"nplurals=4; plural=(n==1 ? 0 : (n%10>=2 && n%10<=4) && (n%100<12 || n%100>14) ? 1 : n!=1 && (n%10>=0 && n%10<=1) || (n%10>=5 && n%10<=9) || (n%100>=12 && n%100<=14) ? 2 : 3);");
