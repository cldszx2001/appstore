OC.L10N.register(
    "files_lock",
    {
    "Unlock file" : "Odemknout soubor",
    "Lock file" : "Zamknout soubor",
    "Locked by {0}" : "Uzamkl(a) {0}",
    "Temporary files lock" : "Dočasný zámek souborů",
    "Temporary lock your files" : "Dočasně zamykejte své soubory",
    "Allow your users to temporary lock their files to avoid conflicts while working on shared files." : "Umožňuje vašim uživatelům dočasně uzamykat své soubory a vyhýbat se tak konfliktům při práci na sdílených souborech."
},
"nplurals=4; plural=(n == 1 && n % 1 == 0) ? 0 : (n >= 2 && n <= 4 && n % 1 == 0) ? 1: (n % 1 != 0 ) ? 2 : 3;");
