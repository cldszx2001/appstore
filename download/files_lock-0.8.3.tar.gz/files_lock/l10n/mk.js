OC.L10N.register(
    "files_lock",
    {
    "Unlock file" : "Отклучи датотека",
    "Lock file" : "Заклучи датотека",
    "Locked by {0}" : "Заклучена од {0}",
    "Temporary files lock" : "Привремено заклучени датотеки",
    "Temporary lock your files" : "Повремено заклучување на ваши датотеки",
    "Allow your users to temporary lock their files to avoid conflicts while working on shared files." : "Дозволи им на корисниците да ги заклучуваат своите датотеките за да избегнат конфликт додека работат на споделени датотеки."
},
"nplurals=2; plural=(n % 10 == 1 && n % 100 != 11) ? 0 : 1;");
