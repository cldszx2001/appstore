OC.L10N.register(
    "files_lock",
    {
    "Unlock file" : "Vapauta tiedoston lukitus",
    "Lock file" : "Lukitse tiedosto",
    "Locked by {0}" : "Lukituksen teki {0}",
    "Temporary lock your files" : "Lukitse tiedostosi väliaikaisesti"
},
"nplurals=2; plural=(n != 1);");
