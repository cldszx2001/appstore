OC.L10N.register(
    "files_lock",
    {
    "Unlock file" : "Ontgrendel bestand",
    "Lock file" : "Vergrendel bestand",
    "Locked by {0}" : "Vergrendeld door {0}",
    "Temporary files lock" : "Tijdelijke bestandsvergrendeling",
    "Temporary lock your files" : "Tijdelijk je bestanden vergrendelen",
    "Allow your users to temporary lock their files to avoid conflicts while working on shared files." : "Staat je gebruikers toe om tijdelijk hun bestanden te vergrendelen, om conflicten te vermijden terwijl ze aan gedeelde bestanden werken."
},
"nplurals=2; plural=(n != 1);");
