OC.L10N.register(
    "files_lock",
    {
    "Unlock file" : "Desverrolhar lo fichièr",
    "Lock file" : "Verrolhar lo fichièr",
    "Locked by {0}" : "Verrolhar per {0}",
    "Temporary lock your files" : "Verrolhar temporàriament vòstres fichièrs"
},
"nplurals=2; plural=(n > 1);");
