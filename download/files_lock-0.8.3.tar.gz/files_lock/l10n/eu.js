OC.L10N.register(
    "files_lock",
    {
    "Unlock file" : "Desblokeatu fitxategia",
    "Lock file" : "Fitxategia blokeatu",
    "Locked by {0}" : "{0}-k blokeatuta",
    "Temporary files lock" : "Aldi baterako fitxategien blokeoak",
    "Temporary lock your files" : "Zure fitxategiak aldi baterako blokeatu"
},
"nplurals=2; plural=(n != 1);");
