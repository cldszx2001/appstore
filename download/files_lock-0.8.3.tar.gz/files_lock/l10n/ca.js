OC.L10N.register(
    "files_lock",
    {
    "Unlock file" : "Desbloqueja el fitxer",
    "Lock file" : "Bloqueja el fitxer",
    "Locked by {0}" : "Bloquejat per {0}",
    "Temporary files lock" : "Bloqueig temporal dels fitxers",
    "Temporary lock your files" : "Bloqueja temporalment els teus fitxers",
    "Allow your users to temporary lock their files to avoid conflicts while working on shared files." : "Permet als usuaris bloquejar temporalment els seus fitxers per evitar conflictes mentre es treballa en fitxers compartits."
},
"nplurals=2; plural=(n != 1);");
