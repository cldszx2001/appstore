OC.L10N.register(
    "files_lock",
    {
    "Unlock file" : "שחרור קובץ",
    "Lock file" : "נעילת קובץ",
    "Locked by {0}" : "ננעל על ידי {0}",
    "Temporary files lock" : "נעילת קבצים זמנית",
    "Temporary lock your files" : "לנעול את הקבצים שלך באופן זמני",
    "Allow your users to temporary lock their files to avoid conflicts while working on shared files." : "מאפשר למשתמשים שלך לנעול את הקבצים שלהם כדי למנוע סתירות בעת עבודה על קבצים משותפים."
},
"nplurals=4; plural=(n == 1 && n % 1 == 0) ? 0 : (n == 2 && n % 1 == 0) ? 1: (n % 10 == 0 && n % 1 == 0 && n > 10) ? 2 : 3;");
