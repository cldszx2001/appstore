OC.L10N.register(
    "files_lock",
    {
    "Unlock file" : "Desbloquear ficheiro",
    "Lock file" : "Bloquear ficheiro",
    "Locked by {0}" : "Bloqueado por {0}",
    "Temporary files lock" : "Bloqueo temporal de ficheiros",
    "Temporary lock your files" : "Bloquear temporalmente os seus ficheiros",
    "Allow your users to temporary lock their files to avoid conflicts while working on shared files." : "Permitir aos seus usuarios bloquear temporalmente os seus ficheiros para evitar conflitos mentres traballan en ficheiros compartidos."
},
"nplurals=2; plural=(n != 1);");
