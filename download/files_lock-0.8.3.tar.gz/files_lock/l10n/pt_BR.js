OC.L10N.register(
    "files_lock",
    {
    "Unlock file" : "Destravar arquivo",
    "Lock file" : "Travar arquivo",
    "Locked by {0}" : "Travado por {0}",
    "Temporary files lock" : "Bloquear arquivos temporariamente",
    "Temporary lock your files" : "Travar temporariamente seus arquivos ",
    "Allow your users to temporary lock their files to avoid conflicts while working on shared files." : "Permitir que usuários bloqueiem temporariamente seus arquivos para evitar conflitos enquanto trabalham em arquivos compartilhados."
},
"nplurals=2; plural=(n > 1);");
