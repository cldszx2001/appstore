OC.L10N.register(
    "files_lock",
    {
    "Unlock file" : "Ξεκλείδωμα αρχείου",
    "Lock file" : "Κλείδωμα αρχείου",
    "Locked by {0}" : "Κλειδώθηκε από {0}",
    "Temporary files lock" : "Κλείδωμα προσωρινών αρχείων",
    "Temporary lock your files" : "Κλειδώστε προσωρινά τα αρχεία σας",
    "Allow your users to temporary lock their files to avoid conflicts while working on shared files." : "Επιτρέπει στους χρήστες σας να κλειδώνουν προσωρινά τα αρχεία τους για αποφυγή διενέξεων κατά την εργασία με κοινόχρηστα αρχεία."
},
"nplurals=2; plural=(n != 1);");
