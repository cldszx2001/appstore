OC.L10N.register(
    "files_lock",
    {
    "Unlock file" : "ファイルのロックを解除",
    "Lock file" : "ファイルをロック",
    "Locked by {0}" : "{0}によってロックされました",
    "Temporary files lock" : "一時的なファイルのロック ",
    "Temporary lock your files" : "ファイルを一時的にロック",
    "Allow your users to temporary lock their files to avoid conflicts while working on shared files." : "ユーザーがファイルを一時的にロックして、共有ファイルでの作業中にコンフリクトを避けることができます。"
},
"nplurals=1; plural=0;");
