OC.L10N.register(
    "files_lock",
    {
    "Unlock file" : "Déverrouiller le fichier",
    "Lock file" : "Verrouiller le fichier",
    "Locked by {0}" : "Verrouillé par {0}",
    "Temporary files lock" : "Verrouillage temporaire des fichiers ",
    "Temporary lock your files" : "Verrouillez temporairement vos fichiers",
    "Allow your users to temporary lock their files to avoid conflicts while working on shared files." : "Autoriser vos utilisateurs à verrouiller temporairement leurs fichiers pour éviter des conflits lorsqu'ils travaillent sur des documents partagés."
},
"nplurals=2; plural=(n > 1);");
