OC.L10N.register(
    "files_lock",
    {
    "Unlock file" : "Lås upp fil",
    "Lock file" : "Lås fil",
    "Locked by {0}" : "Låst av {0}",
    "Temporary files lock" : "Tillfällig låsning av filer",
    "Temporary lock your files" : "Tillfälligt låsa dina filer",
    "Allow your users to temporary lock their files to avoid conflicts while working on shared files." : "Låt dina användare tillfälligt låsa sina filer för att undvika konflikter när de arbetar med delade filer."
},
"nplurals=2; plural=(n != 1);");
