OC.L10N.register(
    "files_lock",
    {
    "Unlock file" : "解锁文件",
    "Lock file" : "锁定文件",
    "Locked by {0}" : "已经由 {0} 锁定",
    "Temporary files lock" : "临时文件锁定",
    "Temporary lock your files" : "临时锁定你的文件",
    "Allow your users to temporary lock their files to avoid conflicts while working on shared files." : "允许您的用户临时锁定其文件，以避免在处理共享文件时发生冲突。"
},
"nplurals=1; plural=0;");
