OC.L10N.register(
    "files_lock",
    {
    "Unlock file" : "Fájl feloldása",
    "Lock file" : "Fájl zárolása",
    "Locked by {0}" : "Zárolva {0} által",
    "Temporary lock your files" : "Zárold ideiglenesen a fájljaid"
},
"nplurals=2; plural=(n != 1);");
