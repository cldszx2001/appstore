OC.L10N.register(
    "files_lock",
    {
    "Unlock file" : "Atrakinti failą",
    "Lock file" : "Užrakinti failą",
    "Locked by {0}" : "Užrakino {0}",
    "Temporary files lock" : "Laikinasis failų užraktas",
    "Temporary lock your files" : "Laikinai užrakinti savo failus",
    "Allow your users to temporary lock their files to avoid conflicts while working on shared files." : "Leidžia naudotojams laikinai blokuoti savo failus, kad išvengti veiklos konfliktų dirbant su bendrinamais failais."
},
"nplurals=4; plural=(n % 10 == 1 && (n % 100 > 19 || n % 100 < 11) ? 0 : (n % 10 >= 2 && n % 10 <=9) && (n % 100 > 19 || n % 100 < 11) ? 1 : n % 1 != 0 ? 2: 3);");
